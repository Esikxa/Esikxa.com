/* p-scroll */
	const ps50 = new PerfectScrollbar('.compose-mail', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});