(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(self, function() {
return /******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!*****************************!*\
  !*** ./resources/js/app.js ***!
  \*****************************/
/*
This file will be used by jetstream to add alpine.js. This file must exist to install jetstream successfully.
You can remove it if you don't want to use jetstream.
*/
/** CKEditor 5*/
// import ClassicEditor from '@ckeditor/ckeditor5-build-classic/build/ckeditor';
// window.ClassicEditor = ClassicEditor;
/******/ 	return __webpack_exports__;
/******/ })()
;
});